# Le ricette di Francy — Android

Progetto Android con WebView e Supabase.

## Build senza PC
Il repository include `.github/workflows/build-apk.yml`. Dopo aver caricato il progetto su GitHub:
1. Aprire la scheda **Actions**.
2. Selezionare **Build APK**.
3. Premere **Run workflow**.
4. Al termine, aprire l'esecuzione completata e scaricare l'artifact **LeRicetteDiFrancy-debug**.
5. Estrarre l'APK e installarlo sul telefono.

La chiave Supabase presente nell'app è una publishable key e non una service-role key.
